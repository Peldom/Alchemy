# PNN_python
Probabilistic Neural Network for classification
