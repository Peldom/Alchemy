source /pubhome/jcyang/miniconda3/bin/activate

# conda create -n dgl90 requests pytorch torchvision cudatoolkit=9.0 dgl-cuda9.0 rdkit -c pytorch -c rdkit -c dglteam -y

conda activate dgl90

export CUDA_VISIBLE_DEVICES=0

# https://github.com/tencent-alchemy/Alchemy

python train.py --model mgcn

# python train.py --model sch --epochs 250
