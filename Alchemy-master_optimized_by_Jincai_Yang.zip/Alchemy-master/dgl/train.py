# -*- coding:utf-8 -*-
"""Sample training code
"""
import argparse
import pandas as pd
from datetime import datetime as dt

import torch as th
import torch.nn as nn
import torch.nn.functional as F

from sch import SchNetModel
from mgcn import MGCNModel
from torch.utils.data import DataLoader
from Alchemy_dataset import TencentAlchemyDataset, batcher


def train(model, data_loader, device, optimizer):
    model.train()
    loss_all = 0
    for batch in data_loader:
        batch.graph.to(device)
        batch.label = batch.label.to(device)
        optimizer.zero_grad()
        y_pred = model(batch.graph)
        loss = F.mse_loss(y_pred, batch.label)
        loss.backward()
        loss_all += loss.item() * len(batch.label)
        optimizer.step()
    mean_loss = loss_all / len(data_loader.dataset)
    return mean_loss


def evaluate(model, data_loader, device):
    model.eval()
    mae = 0
    for batch in data_loader:
        batch.graph.to(device)
        batch.label = batch.label.to(device)
        y_pred = model(batch.graph)
        batch_mae = F.l1_loss(y_pred, batch.label)
        mae += batch_mae.item() * len(batch.label)
    return mae / len(data_loader.dataset)


def predict(model, data_loader, device):
    model.eval()
    targets = {}
    for batch in data_loader:
        batch.graph.to(device)
        batch.label = batch.label.to(device)
        y_pred = model(batch.graph)
        for i in range(len(batch.label)):
            targets[batch.label[i].item()] = y_pred[i].tolist()
    return targets


def write_csv(targets, file_name):
    df_targets = pd.DataFrame.from_dict(
        targets,
        orient="index",
        columns=['property_%d' % x for x in range(12)])
    df_targets.sort_index(inplace=True)
    df_targets.to_csv(file_name, index_label='gdb_idx')


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-M",
                        "--model",
                        help="model name (sch or mgcn)",
                        default="sch")
    parser.add_argument("--epochs",
                        help="number of epochs",
                        type=int,
                        default=250)
    parser.add_argument("-P",
                        "--patience",
                        help="number of epochs to wait",
                        type=int,
                        default=10)
    parser.add_argument("-B", "--batch_size", type=int, default=20)
    parser.add_argument("-D",
                        "--debug",
                        action="store_true",
                        help="train on valid set for debug")
    parser.add_argument("-O", "--output", help="save predict result")
    args = parser.parse_args()
    device = th.device('cuda:0' if th.cuda.is_available() else 'cpu')

    if args.debug:
        dev = TencentAlchemyDataset(mode="valid")
        args.epochs = 3
    else:
        dev = TencentAlchemyDataset(mode="dev")
    valid = TencentAlchemyDataset(mode="valid")
    test = TencentAlchemyDataset(mode='test')

    dev_loader = DataLoader(dev,
                            batch_size=args.batch_size,
                            collate_fn=batcher(),
                            shuffle=True)
    valid_loader = DataLoader(valid,
                              batch_size=args.batch_size,
                              collate_fn=batcher())
    test_loader = DataLoader(test,
                             batch_size=args.batch_size,
                             collate_fn=batcher())

    if args.model == "sch":
        model = SchNetModel(norm=True, output_dim=12)
    if args.model == "mgcn":
        model = MGCNModel(norm=True, output_dim=12)
    model.set_mean_std(dev.mean, dev.std, device)
    model.to(device)

    if args.output is None:
        args.output = args.model + '_test_target.csv'
    optimizer = th.optim.Adam(model.parameters(), lr=0.0001)
    best_mae = 100
    wait = 0
    start = dt.now()
    for i in range(args.epochs):
        loss = train(model, dev_loader, device, optimizer)
        mae = evaluate(model, valid_loader, device)
        if mae <= best_mae:
            wait = 0
            targets = predict(model, test_loader, device)
            write_csv(targets, args.output)
            best_mae = mae
        else:
            wait += 1
        time_epoch = ((dt.now() - start) / (i + 1)).seconds
        info = f"{dt.now()} epoch: {i+1}/{args.epochs} {time_epoch}s/epoch"
        info += f" wait: {wait} dev_loss: {loss:.3f} valid_mae: {mae:.3f}"
        if i % 5 == 0:
            train_mae = evaluate(model, dev_loader, device)
            info += f" train_mae: {train_mae:.3f}"
        print(info)
        if wait > args.patience:
            break
    print(f'Saved result for test on best model on valid at {args.output}.')