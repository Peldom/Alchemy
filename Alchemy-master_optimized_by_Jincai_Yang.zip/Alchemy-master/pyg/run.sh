source /pubhome/jcyang/miniconda3/bin/activate
# conda create -n pyg92 pytorch torchvision cudatoolkit=9.2 requests rdkit -c rdkit -y
conda activate pyg92

# https://github.com/rusty1s/pytorch_geometric/issues/120#issuecomment-487322685
# conda install gcc_linux-64 gxx_linux-64
# pip install --no-cache-dir torch-scatter torch-sparse torch-cluster
# pip install torch-geometric

export CUDA_VISIBLE_DEVICES=0
python mpnn.py

# nvidia-smi 
# 人人都能看懂的LSTM
# https://zhuanlan.zhihu.com/p/32085405
# 
# 人人都能看懂的GRU
# https://zhuanlan.zhihu.com/p/32481747
