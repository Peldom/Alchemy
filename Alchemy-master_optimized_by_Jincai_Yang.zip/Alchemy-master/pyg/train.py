# -*- coding:utf-8 -*-
"""Sample training code
"""
import argparse
import pandas as pd
from datetime import datetime as dt

import torch
import torch.nn as nn
import torch.nn.functional as F

import torch_geometric.transforms as T
from Alchemy_dataset import TencentAlchemyDataset
from torch_geometric.nn import NNConv, Set2Set
from torch_geometric.data import DataLoader
from torch_geometric.utils import remove_self_loops


class Complete(object):
    def __call__(self, data):
        device = data.edge_index.device

        row = torch.arange(data.num_nodes, dtype=torch.long, device=device)
        col = torch.arange(data.num_nodes, dtype=torch.long, device=device)

        row = row.view(-1, 1).repeat(1, data.num_nodes).view(-1)
        col = col.repeat(data.num_nodes)
        edge_index = torch.stack([row, col], dim=0)

        edge_attr = None
        if data.edge_attr is not None:
            idx = data.edge_index[0] * data.num_nodes + data.edge_index[1]
            size = list(data.edge_attr.size())
            size[0] = data.num_nodes * data.num_nodes
            edge_attr = data.edge_attr.new_zeros(size)
            edge_attr[idx] = data.edge_attr

        edge_index, edge_attr = remove_self_loops(edge_index, edge_attr)
        data.edge_attr = edge_attr
        data.edge_index = edge_index

        return data


class MPNN(torch.nn.Module):
    def __init__(self,
                 node_input_dim=15,
                 edge_input_dim=5,
                 output_dim=12,
                 node_hidden_dim=64,
                 edge_hidden_dim=128,
                 num_step_message_passing=6,
                 num_step_set2set=6):
        super(MPNN, self).__init__()
        self.num_step_message_passing = num_step_message_passing
        self.lin0 = nn.Linear(node_input_dim, node_hidden_dim)
        edge_network = nn.Sequential(
            nn.Linear(edge_input_dim, edge_hidden_dim), nn.ReLU(),
            nn.Linear(edge_hidden_dim, node_hidden_dim * node_hidden_dim))
        self.conv = NNConv(node_hidden_dim,
                           node_hidden_dim,
                           edge_network,
                           aggr='mean',
                           root_weight=False)
        self.gru = nn.GRU(node_hidden_dim, node_hidden_dim)

        self.set2set = Set2Set(node_hidden_dim,
                               processing_steps=num_step_set2set)
        self.lin1 = nn.Linear(2 * node_hidden_dim, node_hidden_dim)
        self.lin2 = nn.Linear(node_hidden_dim, output_dim)

    def forward(self, data):
        out = F.relu(self.lin0(data.x))
        h = out.unsqueeze(0)

        for i in range(self.num_step_message_passing):
            m = F.relu(self.conv(out, data.edge_index, data.edge_attr))
            out, h = self.gru(m.unsqueeze(0), h)
            out = out.squeeze(0)

        out = self.set2set(out, data.batch)
        out = F.relu(self.lin1(out))
        out = self.lin2(out)
        return out


def train(model, data_loader, device, optimizer):
    model.train()
    loss_all = 0
    for batch in data_loader:
        batch = batch.to(device)
        optimizer.zero_grad()
        y_pred = model(batch)
        loss = F.mse_loss(y_pred, batch.y)
        loss.backward()
        loss_all += loss.item() * batch.num_graphs
        optimizer.step()
    torch.cuda.empty_cache()
    mean_loss = loss_all / len(data_loader.dataset)
    return mean_loss


def evaluate(model, data_loader, device):
    model.eval()
    mae = 0
    with torch.no_grad():
        for batch in data_loader:
            batch = batch.to(device)
            y_pred = model(batch)
            batch_mae = F.l1_loss(y_pred, batch.y)
            mae += batch_mae.item() * batch.num_graphs
    torch.cuda.empty_cache()
    return mae / len(data_loader.dataset)


def predict(model, data_loader, device):
    model.eval()
    targets = {}
    with torch.no_grad():
        for batch in data_loader:
            batch = batch.to(device)
            y_pred = model(batch)
            for i in range(len(batch.y)):
                targets[batch.y[i].item()] = y_pred[i].tolist()
    torch.cuda.empty_cache()
    return targets


def write_csv(targets, file_name):
    df_targets = pd.DataFrame.from_dict(
        targets,
        orient="index",
        columns=['property_%d' % x for x in range(12)])
    df_targets.sort_index(inplace=True)
    df_targets.to_csv(file_name, index_label='gdb_idx')


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-M",
                        "--model",
                        help="model name (mpnn)",
                        default="mpnn")
    parser.add_argument("--epochs",
                        help="number of epochs",
                        type=int,
                        default=250)
    parser.add_argument("-P",
                        "--patience",
                        help="number of epochs to wait",
                        type=int,
                        default=10)
    parser.add_argument("-B", "--batch_size", type=int, default=64)
    parser.add_argument("-D",
                        "--debug",
                        action="store_true",
                        help="train on valid set for debug")
    parser.add_argument("-O", "--output", help="save predict result")
    args = parser.parse_args()
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

    transform = T.Compose([Complete(), T.Distance(norm=False)])
    root = 'data-bin'
    if args.debug:
        dev = TencentAlchemyDataset(root=root,
                                    mode="valid",
                                    transform=transform)
        args.epochs = 3
    else:
        dev = TencentAlchemyDataset(root=root, mode="dev", transform=transform)
    valid = TencentAlchemyDataset(root=root, mode="valid", transform=transform)
    test = TencentAlchemyDataset(root=root, mode="test", transform=transform)

    dev_loader = DataLoader(
        dev,
        batch_size=args.batch_size,
        shuffle=True,
    )
    valid_loader = DataLoader(
        valid,
        batch_size=args.batch_size,
    )
    test_loader = DataLoader(
        test,
        batch_size=args.batch_size,
    )

    if args.model == "mpnn":
        model = MPNN(node_input_dim=dev.num_features).to(device)
    print(model, flush=True)

    if args.output is None:
        args.output = args.model + '_test_target.csv'
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    best_mae = 100
    wait = 0
    start = dt.now()
    for i in range(args.epochs):
        loss = train(model, dev_loader, device, optimizer)
        mae = evaluate(model, valid_loader, device)
        if mae <= best_mae:
            wait = 0
            targets = predict(model, test_loader, device)
            write_csv(targets, args.output)
            best_mae = mae
        else:
            wait += 1
        time_epoch = ((dt.now() - start) / (i + 1)).seconds
        info = f"{dt.now()} epoch: {i+1}/{args.epochs} {time_epoch}s/epoch"
        info += f" wait: {wait} dev_loss: {loss:.3f} valid_mae: {mae:.3f}"
        if i % 5 == 0:
            train_mae = evaluate(model, dev_loader, device)
            info += f" train_mae: {train_mae:.3f}"
        print(info, flush=True)
        if wait > args.patience:
            break
    print(f'Saved result for test on best model on valid at {args.output}, elapsed time: {dt.now()-start}.')
